Katalog = class(Group)

function Katalog:init(x)
    -- you can accept and set parameters here
    Group.init(self)
    
    -- B x H x (T | L)
    -- Matratze M: 1400 x 200 x 2000
    -- 1 Stck
    matte = Bar(1400, 200, 2000)
    matte:setTexture("Environments:Night Down")
    self:addObject("matte", matte)
    matte:moveTo(500, 1500, 5000)
    print("matte: ", matte:getWidth(), matte:getLength(), matte:getHeight())
    
    -- Balken A: 100 x 100 x (Matratzenlaenge + 2 x Balken-A-breite)
    -- 2 Stck, i.e. links und rechts
    barA = Bar(100, 100, matte:getLength() + 2 * 100)
    self:addObject("barA", barA)
    barA:setTexture(barTextureA)
    barA:moveTo(-2000, 1500, 5000)
    print("bar A: ", barA:getWidth(), barA:getHeight(), barA:getLength())
    
    -- Balken B: 100 x 100 x Matratzenbreite
    -- 2 Stck, i.e. kopf- und fussende
    barB = Bar(100, 100, matte:getWidth())
    barB:setTexture(barTextureB)
    self:addObject("barB", barB)
    barB:moveTo(-2000, 1300, 5000)
    print("bar B: ", barB:getWidth(), barB:getHeight(), barB:getLength())
    
    -- Planke D: 120 x 60 x (Matratzenlaenge + 2 x Balken-B-breite - 2 x Planken-C-breite)
    -- 2 Stck, i.e. linke und rechte Seite
    plankD = Bar(120, 60, matte:getLength() + 2 * barB:getWidth() - 2 * unterbauoffset)
    plankD:setTexture(barTextureB)
    self:addObject("plankD", plankD)
    plankD:moveTo(-2000, 900, 5000)
    print("plnk lg: ", plankD:getWidth(), plankD:getHeight(), plankD:getLength())

    -- Planke C: 120 x 60 x (Matratzenbreite + 2 x Balken-A-breite)
    -- 2 Stck, i.e. kopf- und fussende
    plankC = Bar(120, 60, matte:getWidth() + 2 * barA:getWidth() - 2 * plankD:getWidth() - 2 * unterbauoffset)
    self:addObject("plankC", plankC)
    plankC:moveTo(-2000, 1100, 5000)
    print("plnk sh: ", plankC:getWidth(), plankC:getHeight(), plankC:getLength())
   
    -- Fuss E: 100 x 100 x (betthoehe - Planken-C/D-dicke - Balken-A/B-dicke)
    -- 4 Stck
    fussE = Bar(100, 100, betthoehe - plankC:getHeight() - barA:getHeight())
    fussE:setTexture(barTextureA)
    self:addObject("fussE", fussE)
    fussE:moveTo(-2000, 700, 5000)
    print("fuss: ", fussE:getWidth(), fussE:getHeight(), fussE:getLength())
    
    -- Latte L: 30 x 20 x (Matratzenbreite)
    -- 40 Stck
    latteL = Bar(30, 20, matte:getWidth())
    latteL:setTexture(latteTexture)
    self:addObject("latteL", latteL)
    latteL:moveTo(-2000, 500, 5000)
    print("latte quer: \n\t", latteL:getWidth(), latteL:getHeight(), latteL:getLength())
    
    -- Wand W: Bettbreite, i.e. Matratzenbreite + 2 x Balken-A-breite, x 800 x 20
    -- 1 Stck
    wandW = Bar(matte:getWidth() + 2 * barA:getWidth(), 800, 20)
    self:addObject("wandW", wandW)
    wandW:moveTo(2500, 1500, 5000)

end

function Katalog:draw()
    -- Codea does not automatically call this method
end

function Katalog:touched(touch)
    -- Codea does not automatically call this method
end
