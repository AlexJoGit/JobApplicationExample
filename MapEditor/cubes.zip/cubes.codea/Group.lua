Group = class(Bar)

function Group:init(x)
    -- base class constructor
    Bar.init(self, 0, 0, 0)
    
    self.isVisible = true
    self.objects = {}
end

function Group:addObject(name, bar)
    self.objects[name] = bar:clone()
end

function Group:removeObject(name)
    self.objects[name] = nil
end

function Group:draw()
    
    if not self.isVisible then return end
    
    for i,o in ipairs(self.objects) do
        o:draw()
    end
end

-- end of file
 