function setup()
    
    displayMode(OVERLAY)
    
    parameter.number("camX", -3000, 3000, 0)
    parameter.number("camY", -2000, 2000, 0)
    parameter.number("camZ", -2000, 6000, -1000)

    parameter.boolean("Katalog", false)
    parameter.boolean("Alle Teile", true, OnAllesChanged)
    parameter.boolean("Rueckwand", true)
    parameter.boolean("Matratze", true)
    parameter.boolean("Lattenrost", true)
    parameter.boolean("Rahmen", true)
    parameter.boolean("Unterbau", true)
    parameter.boolean("Fuesse", true)
    parameter.boolean("Lattenrost", true)
    
    -- camera position
    camX,camY,camZ = 0, 200, -1000
    lookX,lookY,lookZ = 0, 0, 1000 --set where the camera is looking, straight ahead
    
    -- img = image(CAMERA)
    -- sprite(CAMERA, x, y)
    
    -- cameraSource(CAMERA_BACK)

    -- movement per draw
    -- initially move object to the objects right
    moveCam = 5
    -- initially move object toward us
    moveZ = -5 
    --rotate object
    --this is new code.....     
    --initial rotation 
    --we'll rotate the cube so we can see it properly
    RX,RY,RZ=0,0,0 --change (in pixels) in rotation per draw
    --we'll rotate in all three axes
    rX,rY,rZ=0.1,0.5,1.0
    
    -- create some objects
    cubeX = Cube(100)
    cubeX:setTexture("Platformer Art:Block Special")
    cubeX:moveTo(-1000, 1000, 2000)
    
    cube0 = Cube(100)
    cube0:setTexture("UI:Blue Panel")
    -- set cube0 position, slightly to left of centre
    cube0:moveTo(100, 0, 1000)
    
    cube1 = Cube(100)
    cube1:moveBy(0, -400, 300)
    
    -- Katalog
    latteTexture = "Blocks:Cactus Top"
    barTextureA = "Blocks:Redsand"
    barTextureB = "Blocks:Lava"

    bettVariante2()    
    
end

function bettVariante1()
    
    
    betthoehe = 300 -- ohne matratze
    fussoffset = 20

    -- B x H x (T | L)
    -- Matratze M: 1400 x 200 x 2000
    -- 1 Stck
    matte = Bar(1400, 200, 2000)
    matte:setTexture("Environments:Night Down")
    matte:moveTo(500, 1500, 5000)
    
    -- Balken A: 100 x 100 x (Matratzenlaenge + 2 x Balken-A-breite)
    -- 2 Stck, i.e. links und rechts
    barA = Bar(100, 100, matte:getLength() + 2 * 100)
    barA:setTexture(barTextureA)
    barA:moveTo(-2000, 1500, 5000)
    print("bar A: ", barA:getLength())

    -- Balken B: 100 x 100 x Matratzenbreite
    -- 2 Stck, i.e. kopf- und fussende
    barB = Bar(100, 100, matte:getWidth())
    barB:setTexture(barTextureB)
    barB:moveTo(-2000, 1300, 5000)
    print("bar B: ", barB:getLength())
    
    -- Planke C: 120 x 60 x (Matratzenbreite + 2 x Balken-A-breite)
    -- 2 Stck, i.e. kopf- und fussende
    plankC = Bar(100, 60, matte:getWidth() + 2 * barA:getWidth())
    plankC:moveTo(-2000, 1100, 5000)
    
    -- Planke D: 120 x 60 x (Matratzenlaenge + 2 x Balken-B-breite - 2 x Planken-C-breite)
    -- 2 Stck, i.e. linke und rechte Seite
    plankD = Bar(100, 60, matte:getLength() + 2 * barB:getWidth() - 2 * plankC:getWidth())
    plankD:setTexture(barTextureB)
    plankD:moveTo(-2000, 900, 5000)
   
    -- Fuss E: 100 x 100 x (betthoehe - Planken-C/D-dicke - Balken-A/B-dicke)
    -- 4 Stck
    fussE = Bar(100, 100, betthoehe - plankC:getHeight() - barA:getHeight())
    fussE:setTexture(barTextureA)
    fussE:moveTo(-2000, 700, 5000)
    print("fuss: "..fussE:getLength())
    -- Latte L: 30 x 20 x (Matratzenbreite)
    -- 40 Stck
    latteL = Bar(30, 20, matte:getWidth())
    latteL:setTexture(latteTexture)
    latteL:moveTo(-2000, 500, 5000)
    print("latte quer: ", latteL:getWidth(), latteL:getHeight(), latteL:getLength())
    
    -- Wand W: Bettbreite, i.e. Matratzenbreite + 2 x Balken-A-breite, x 800 x 20
    -- 1 Stck
    wandW = Bar(matte:getWidth() + 2 * barA:getWidth(), 800, 20)
    wandW:moveTo(2500, 1500, 5000)
    
    -- alle Teile
    bett = {
      m = matte:clone()
    , rlinks = barA:clone()
    , rrechts = barA:clone()
    , rkopfende = barB:clone()
    , rfussende = barB:clone()
    , pkopfende = plankC:clone()
    , pfussende = plankC:clone()
    , plinks = plankD:clone()
    , prechts = plankD:clone()
    , fvornlinks = fussE:clone()
    , fvornrechts = fussE:clone()
    , fhintenlinks = fussE:clone()
    , fhintenrechts = fussE:clone()
    , rueckwand = wandW:clone()
    , latte1 = latteL:clone()
    }
    
    bett.center = vec3(0, 0, 2000)
    bett.dimensions = vec3(
      bett["rrechts"]:getWidth() + bett["m"]:getWidth() + bett["rlinks"]:getWidth()
    , bett["rlinks"]:getHeight()
      + bett["plinks"]:getHeight()
      + bett["fvornlinks"]:getLength() -- fuss wird gedreht
    , bett["rkopfende"]:getHeight()
      + bett["m"]:getLength()
      + bett["rfussende"]:getHeight()
    )
    
    local part
    local matteY = bett.center.y
    part = bett["m"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(0, matteY, 0)
    
    local rahmenY = -(50 + 20)
    part = bett["rlinks"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(-(700 + 50), rahmenY, 0)
    
    part = bett["rrechts"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy( 700 + 50, rahmenY, 0)
    
    part = bett["rkopfende"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy( 0, rahmenY, 1000 + 50)
    part:rotateBy(0, 90.0, 0)
    
    part = bett["rfussende"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(0, rahmenY, -(1000 + 50))
    part:rotateBy(0, 90.0, 0)
    
    local plankeY = 
      matteY 
    - bett["m"]:getHeight() / 2.0 
    - plankC:getHeight() / 2.0 
    - latteL:getHeight()
    local plankerechts = (bett.dimensions.x - plankC:getWidth()) / 2.0
    local plankelinks = -plankerechts
    local plankehinten = (bett.dimensions.z - plankD:getWidth()) / 2.0
    local plankevorn = -plankehinten
    part = bett["plinks"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(plankelinks, plankeY, 0)
    
    part = bett["prechts"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(plankerechts, plankeY, 0)
    
    part = bett["pkopfende"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(0, plankeY, plankehinten)
    part:rotateBy(0, 90.0, 0)
    
    part = bett["pfussende"]
    if part then
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(0, plankeY, plankevorn)
    part:rotateBy(0, 90.0, 0)
    end
    
    -- füsse
    -- abgeleitete positionen
    local fussY = plankeY - (bett["pkopfende"]:getHeight() + fussE:getLength()) / 2.0
    local fussrechts = (bett.dimensions.x - fussE:getWidth()) / 2.0 - fussoffset
    local fusslinks = -fussrechts
    local fusshinten = (bett.dimensions.z - fussE:getHeight()) / 2.0 - fussoffset
    local fussvorn = -fusshinten
    
    part = bett["fhintenrechts"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(fussrechts, fussY, fusshinten)
    part:rotateBy(90.0, 0, 0)
    
    part = bett["fhintenlinks"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(fusslinks, fussY, fusshinten)
    part:rotateBy(90.0, 0, 0)

    part = bett["fvornrechts"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(fussrechts, fussY, fussvorn)
    part:rotateBy(90.0, 0, 0)
   
    part = bett["fvornlinks"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(fusslinks, fussY, fussvorn)
    part:rotateBy(90.0, 0, 0)

    -- rückwand
    local wandY = 50
    part = bett["rueckwand"]
    -- part:setTexture(CAMERA)
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(0, wandY, (1000 + 100 + 10))
    
    -- lattenrost
    local lattenY = -(100 + 10)
    part = bett["latte1"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(0, lattenY, 0)
    part:rotateBy(0, 90.0, 0)
    
end

function bettVariante2()
    
    katalog = Group()
    
    betthoehe = 300 -- ohne matratze
    unterbauoffset = 20
    fussoffset = unterbauoffset + 20

    -- B x H x (T | L)
    -- Matratze M: 1400 x 200 x 2000
    -- 1 Stck
    matte = Bar(1400, 200, 2000)
    matte:setTexture("Environments:Night Down")
    katalog:addObject("matte", matte)
    matte:moveTo(500, 1500, 5000)
    print("matte: ", matte:getWidth(), matte:getLength(), matte:getHeight())
    
    -- Balken A: 100 x 100 x (Matratzenlaenge + 2 x Balken-A-breite)
    -- 2 Stck, i.e. links und rechts
    barA = Bar(100, 100, matte:getLength() + 2 * 100)
    barA:setTexture(barTextureA)
    barA:moveTo(-2000, 1500, 5000)
    print("bar A: ", barA:getWidth(), barA:getHeight(), barA:getLength())
    
    -- Balken B: 100 x 100 x Matratzenbreite
    -- 2 Stck, i.e. kopf- und fussende
    barB = Bar(100, 100, matte:getWidth())
    barB:setTexture(barTextureB)
    barB:moveTo(-2000, 1300, 5000)
    print("bar B: ", barB:getWidth(), barB:getHeight(), barB:getLength())
    
    -- Planke D: 120 x 60 x (Matratzenlaenge + 2 x Balken-B-breite - 2 x Planken-C-breite)
    -- 2 Stck, i.e. linke und rechte Seite
    plankD = Bar(120, 60, matte:getLength() + 2 * barB:getWidth() - 2 * unterbauoffset)
    plankD:setTexture(barTextureB)
    plankD:moveTo(-2000, 900, 5000)
    print("plnk lg: ", plankD:getWidth(), plankD:getHeight(), plankD:getLength())

    -- Planke C: 120 x 60 x (Matratzenbreite + 2 x Balken-A-breite)
    -- 2 Stck, i.e. kopf- und fussende
    plankC = Bar(120, 60, matte:getWidth() + 2 * barA:getWidth() - 2 * plankD:getWidth() - 2 * unterbauoffset)
    plankC:moveTo(-2000, 1100, 5000)
    print("plnk sh: ", plankC:getWidth(), plankC:getHeight(), plankC:getLength())
   
    -- Fuss E: 100 x 100 x (betthoehe - Planken-C/D-dicke - Balken-A/B-dicke)
    -- 4 Stck
    fussE = Bar(100, 100, betthoehe - plankC:getHeight() - barA:getHeight())
    fussE:setTexture(barTextureA)
    fussE:moveTo(-2000, 700, 5000)
    print("fuss: ", fussE:getWidth(), fussE:getHeight(), fussE:getLength())
    
    -- Latte L: 30 x 20 x (Matratzenbreite)
    -- 40 Stck
    latteL = Bar(30, 20, matte:getWidth())
    latteL:setTexture(latteTexture)
    latteL:moveTo(-2000, 500, 5000)
    print("latte quer: \n\t", latteL:getWidth(), latteL:getHeight(), latteL:getLength())
    
    -- Wand W: Bettbreite, i.e. Matratzenbreite + 2 x Balken-A-breite, x 800 x 20
    -- 1 Stck
    wandW = Bar(matte:getWidth() + 2 * barA:getWidth(), 800, 20)
    wandW:moveTo(2500, 1500, 5000)
    
    -- alle Teile
    bett = {
      m = matte:clone()
    , rlinks = barA:clone()
    , rrechts = barA:clone()
    , rkopfende = barB:clone()
    , rfussende = barB:clone()
    , pkopfende = plankC:clone()
    , pfussende = plankC:clone()
    , plinks = plankD:clone()
    , prechts = plankD:clone()
    , fvornlinks = fussE:clone()
    , fvornrechts = fussE:clone()
    , fhintenlinks = fussE:clone()
    , fhintenrechts = fussE:clone()
    , rueckwand = wandW:clone()
    , latte1 = latteL:clone()
    , latte2 = latteL:clone()
    , latte3 = latteL:clone()
    , latte4 = latteL:clone()
        , latte5 = latteL:clone()
        , latte6 = latteL:clone()
        , latte7 = latteL:clone()
        , latte8 = latteL:clone()
        , latte9 = latteL:clone()
    , latte10 = latteL:clone()
    , latte11 = latteL:clone()
        , latte12 = latteL:clone()
        , latte13 = latteL:clone()
        , latte14 = latteL:clone()
        , latte15 = latteL:clone()
        , latte16 = latteL:clone()
        , latte17 = latteL:clone()
    , latte18 = latteL:clone()
        , latte19 = latteL:clone()
    , latte20 = latteL:clone()
    , latte21 = latteL:clone()
    , latte22 = latteL:clone()
    , latte23 = latteL:clone()
    , latte24 = latteL:clone()
        , latte25 = latteL:clone()
        , latte26 = latteL:clone()
        , latte27 = latteL:clone()
        , latte28 = latteL:clone()
        , latte29 = latteL:clone()
    , latte30 = latteL:clone()
    , latte31 = latteL:clone()
    , latte32 = latteL:clone()
    , latte33 = latteL:clone()
    , latte34 = latteL:clone()
        , latte35 = latteL:clone()
        , latte36 = latteL:clone()
        , latte37 = latteL:clone()
        , latte38 = latteL:clone()
        , latte39 = latteL:clone()
    , latte40 = latteL:clone()

    }
    
    bett.center = vec3(0, 0, 2000)
    bett.dimensions = vec3(
      bett["rrechts"]:getWidth() + bett["m"]:getWidth() + bett["rlinks"]:getWidth()
    , bett["rlinks"]:getHeight()
      + bett["plinks"]:getHeight()
      + bett["fvornlinks"]:getLength() -- fuss wird gedreht
    , bett["rkopfende"]:getHeight()
      + bett["m"]:getLength()
      + bett["rfussende"]:getHeight()
    )
    
    local part
    local matteY = bett.center.y
    part = bett["m"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(0, matteY, 0)
    
    local rahmenY = -(50 + 20)
    part = bett["rlinks"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(-(700 + 50), rahmenY, 0)
    
    part = bett["rrechts"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy( 700 + 50, rahmenY, 0)
    
    part = bett["rkopfende"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy( 0, rahmenY, 1000 + 50)
    part:rotateBy(0, 90.0, 0)
    
    part = bett["rfussende"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(0, rahmenY, -(1000 + 50))
    part:rotateBy(0, 90.0, 0)
    
    local plankeY = 
      matteY 
    - bett["m"]:getHeight() / 2.0 
    - plankC:getHeight() / 2.0 
    - latteL:getHeight()
    local plankerechts = (bett.dimensions.x - plankC:getWidth()) / 2.0 - unterbauoffset
    local plankelinks = -plankerechts
    local plankehinten = (bett.dimensions.z - plankD:getWidth()) / 2.0 - unterbauoffset
    local plankevorn = -plankehinten
    part = bett["plinks"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(plankelinks, plankeY, 0)
    
    part = bett["prechts"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(plankerechts, plankeY, 0)
    
    part = bett["pkopfende"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(0, plankeY, plankehinten)
    part:rotateBy(0, 90.0, 0)
    
    part = bett["pfussende"]
    if part then
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(0, plankeY, plankevorn)
    part:rotateBy(0, 90.0, 0)
    end
    
    -- füsse
    -- abgeleitete positionen
    local fussY = plankeY - (bett["pkopfende"]:getHeight() + fussE:getLength()) / 2.0
    local fussrechts = (bett.dimensions.x - fussE:getWidth()) / 2.0 - fussoffset
    local fusslinks = -fussrechts
    local fusshinten = (bett.dimensions.z - fussE:getHeight()) / 2.0 - fussoffset
    local fussvorn = -fusshinten
    
    part = bett["fhintenrechts"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(fussrechts, fussY, fusshinten)
    part:rotateBy(90.0, 0, 0)
    
    part = bett["fhintenlinks"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(fusslinks, fussY, fusshinten)
    part:rotateBy(90.0, 0, 0)

    part = bett["fvornrechts"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(fussrechts, fussY, fussvorn)
    part:rotateBy(90.0, 0, 0)
   
    part = bett["fvornlinks"]
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(fusslinks, fussY, fussvorn)
    part:rotateBy(90.0, 0, 0)

    -- rückwand
    local wandY = 50
    part = bett["rueckwand"]
    -- part:setTexture(CAMERA)
    part:moveTo(bett.center.x, bett.center.y, bett.center.z)
    part:moveBy(0, wandY, (1000 + 100 + 10))
    
    -- lattenrost
    local lattenY = -(100 + 10)
    local lattenZ0 = - (bett["m"]:getLength() - latteL:getWidth()) / 2.0
    
    for l = 1, 40 do
        part = bett["latte"..l]
        if part~=nil then
            part:moveTo(bett.center.x, bett.center.y, bett.center.z)
            part:moveBy(0, lattenY, lattenZ0 + (l-1) * 50)
            part:rotateBy(0, 90.0, 0)
        end
    end
    
end
    
function draw()
    
    background(141, 178, 212, 255) --pale background

    -- switch to 2D
    ortho()
    viewMatrix(matrix())
    -- and draw something else
    stroke(25, 0, 255, 78)
    strokeWidth(3)
    line(WIDTH - 10, 10, WIDTH - 10, HEIGHT-20)
--    sprite(CAMERA, WIDTH/2, HEIGHT/2, WIDTH-30, HEIGHT-30)
    
    -- switch to 3D
    perspective() --tells Codea we are drawing 3D
    camera(camX,camY,camZ,lookX,lookY,lookZ)
    
    -- 3D-Controls
    cubeX:draw()
--    cube0:draw()    
    cube1:draw()

    -- Katalog
    katalog:draw()

    if (Katalog) then
        matte:draw()
        barA:draw()
        barB:draw()
        plankC:draw()
        plankD:draw()
        fussE:draw()
        latteL:draw()
        wandW:draw()
    end
    
    -- bett
    if (Matratze) then
        bett["m"]:draw()
    end
    
    if (Rahmen) then
        bett["rlinks"]:draw()
        bett["rrechts"]:draw()
        bett["rkopfende"]:draw()
        bett["rfussende"]:draw()
    end
    
    if (Unterbau) then
        bett["plinks"]:draw()
        bett["prechts"]:draw()
        bett["pkopfende"]:draw()
        bett["pfussende"]:draw()
    end
    
    if (Fuesse) then
        bett["fvornlinks"]:draw()
        bett["fvornrechts"]:draw()
        bett["fhintenrechts"]:draw()
        bett["fhintenlinks"]:draw()
    end
    
    if (Lattenrost) then
        -- lattenrost
        for l = 1, 40 do
            local part = bett["latte"..l]
            if part then part:draw() end
        end
    end
    
    if (Rueckwand) then
        bett["rueckwand"]:draw()
    end
    
    -- the drawing event is also used for computing the movement
    -- i.e. the change in the state of the object in space
    -- due to its motion vectors and motion limitations
    -- here: move cube toward or away from us
    cubeX:rotateBy(0.1, 0.2, 0.2)

    -- moving style: bouncing along z & rotating
    cube0:moveBy(0, 0, moveZ)
    if cube0.center.z < - 1000 or 1000 < cube0.center.z then
        -- i.e. switch direction
        moveZ = -moveZ
    end
    cube0:rotateBy(rX, rY, rZ)

    -- moving style: move along x in an endless loop & rotating
    cube1:moveBy(moveCam, moveCam)
    if cube1.center.x < -1000 or 1000 < cube1.center.x then
        -- i.e. reset position to the most left hand side of the obeject
        -- cube1:moveTo(-800, -800)
        moveCam = -moveCam
    end
    cube1:rotateBy(-rX, -rY, -rZ)
    
    -- "Katalog"
    -- moving style: fixed position & rotating
    matte:rotateBy(0, -rY, 0)
    barA:rotateBy(-rX, -rY, -rZ)
    barB:rotateBy(-rX, -rY, -rZ)
    plankC:rotateBy(-rX, -rY, -rZ)
    plankD:rotateBy(-rX, -rY, -rZ)
    fussE:rotateBy(-rX, -rY, -rZ)
    latteL:rotateBy(-rX, -rY, -rZ)
    wandW:rotateBy(-rX, -rY, -rZ)
        
    -- let the camera follow the cube1
--    camX = cube1.center.x
--    camY = cube1.center.y
--    camZ = cube1.center.z
--    lookX = cube1.center.x

    -- switch to 2D
    ortho()
    viewMatrix(matrix())
    -- and draw something else
    stroke(255, 0, 0)
    strokeWidth(3)
    line(10, 10, 10, HEIGHT-20)
end 

function touched(touch)
    if (touch.state == ENDED) then
    -- Due to the close()bug in Codea v.2.6.1
    -- it is impossible to use this function
    -- since there is no guarantee to savely stop the execution
    -- and return to the editor
    displayMode(OVERLAY)
    alert("Please use the button panel to close the app")
    -- close()
    end
end

function OnAllesChanged(value)
    Rueckwand = value
    Matratze = value
    Lattenrost = value
    Rahmen = value
    Unterbau = value
    Fuesse = value
    Lattenrost = value
end

-- eof
