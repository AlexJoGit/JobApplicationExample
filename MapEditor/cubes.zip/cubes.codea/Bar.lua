Bar = class()

function Bar:init(width, height, depth)
    -- id
    self.id = "bar"
    -- default position
    self.center    = vec3(0, 0, 0)
    self.rotation  = vec3(0, 0, 0)
    -- given dimensions
    self.dimensions = vec3(width, height, depth)
    -- default texture for bars
    self.texture = "Blocks:Cotton Red"

    -- construction of the cubes mesh
    -- each corner will be exactly 0.5 x len away from the centre
    local d = 0.5 * self.dimensions
    --now define the positions of the 8 corners
    local c = {
      vec3(-d.x, -d.y,  d.z) -- Left  bottom front
    , vec3( d.x, -d.y,  d.z) -- Right bottom front
    , vec3( d.x,  d.y,  d.z) -- Right top front
    , vec3(-d.x,  d.y,  d.z) -- Left  top front
    , vec3(-d.x, -d.y, -d.z) -- Left  bottom back
    , vec3( d.x, -d.y, -d.z) -- Right bottom back
    , vec3( d.x,  d.y, -d.z) -- Right top back
    , vec3(-d.x,  d.y, -d.z) -- Left  top back
    }
    
    -- now construct all the triangles,
    -- i.e. 6 sides x 2 triangles each x 3 vertices = 36
    local vert = {
      c[1], c[2], c[3], c[1], c[3], c[4] --Front
    , c[2], c[6], c[7], c[2], c[7], c[3] --Right
    , c[6], c[5], c[8], c[6], c[8], c[7] --Back
    , c[5], c[1], c[4], c[5], c[4], c[8] --Left
    , c[4], c[3], c[7], c[4], c[7], c[8] --Top
    , c[5], c[6], c[2], c[5], c[2], c[1] --Bottom
    }

    -- bottom left, bottom right, top left, top right
    local t = { vec2(0,0),vec2(1,0),vec2(0,1),vec2(1,1) }
    -- apply the texture coordinates to each vertex
    local tex = {
      t[1], t[2], t[4], t[1], t[4], t[3] --Front
    , t[1], t[2], t[4], t[1], t[4], t[3] --Right
    , t[1], t[2], t[4], t[1], t[4], t[3] --Back
    , t[1], t[2], t[4], t[1], t[4], t[3] --Left
    , t[1], t[2], t[4], t[1], t[4], t[3] --Top
    , t[1], t[2], t[4], t[1], t[4], t[3] --Bottom
    }
    
    self.m = mesh()
    self.m.vertices = vert
    self.m.texture = self.texture
    self.m.texCoords = tex
    self.m:setColors(200,200,255,255)
end

function Bar:clone()
    local bar = Bar(self.dimensions.x, self.dimensions.y, self.dimensions.z)
    bar:setTexture(self.texture)
    return bar
end

function Bar:getWidth()
    return self.dimensions.x
end

function Bar:getHeight()
    return self.dimensions.y
end

function Bar:getDepth()
    return self.dimensions.z
end

function Bar:getLength()
    return self.dimensions.z
end

function Bar:setTexture(tex)
    self.texture = tex
    self.m.texture = tex
end

function Bar:moveTo(x, y, z)
    x = x or self.center.x
    y = y or self.center.y
    z = z or self.center.z
    self.center = vec3(x, y, z)
end

function Bar:moveBy(dx, dy, dz)
    dx = dx or 0
    dy = dy or 0
    dz = dz or 0
    self.center = vec3(
      self.center.x + dx
    , self.center.y + dy
    , self.center.z + dz
    )
end

function Bar:rotateBy(dx, dy, dz)
    dx = dx or 0
    dy = dy or 0
    dz = dz or 0
    self.rotation = vec3(
      self.rotation.x + dx
    , self.rotation.y + dy
    , self.rotation.z + dz
    )
end

function Bar:draw()
    -- Codea does not automatically call this method
    pushMatrix()
    resetMatrix()
    translate(self.center.x, self.center.y, self.center.z)
    rotate(self.rotation.x,1,0,0)   --rotate on each axis separately
    rotate(self.rotation.y,0,1,0)
    rotate(self.rotation.z,0,0,1)
    self.m:draw()
    popMatrix()
end

function Bar:touched(touch)
    -- Codea does not automatically call this method
end
