Cube = class(Bar)

function Cube:init(width)
    -- base class constructor
    Bar.init(self, width, width, width)

    -- default texture for cubes
    Bar.setTexture(self, "Blocks:Missing")
    
    print("test: "..self["texture"])

end

-- end of file
